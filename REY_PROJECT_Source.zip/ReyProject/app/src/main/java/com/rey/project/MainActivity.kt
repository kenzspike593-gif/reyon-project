package com.rey.project

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF10131B.toInt())
        }
        root.addView(TextView(this).apply {
            text = "REY PROJECT"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "Android utility dashboard"
            textSize = 14f
            setTextColor(0xFFB8C2D8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        })
        info = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFE8ECF5.toInt())
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0xFF202838.toInt())
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        refreshInfo()
        addButton(root, "Refresh device information") { refreshInfo() }
        addButton(root, "Open sound settings") {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        }
        addButton(root, "Touch test") { showTouchTest() }
        addButton(root, "Check internet connection") { checkInternet() }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.topMargin = 12
        parent.addView(button, params)
    }

    private fun refreshInfo() {
        val refresh = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            windowManager.defaultDisplay.refreshRate else 0f
        val runtime = Runtime.getRuntime()
        info.text = "Device: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "CPU cores: ${runtime.availableProcessors()}\n" +
            "App memory limit: ${runtime.maxMemory() / (1024 * 1024)} MB\n" +
            "Free app memory: ${runtime.freeMemory() / (1024 * 1024)} MB\n" +
            "Display refresh: ${"%.0f".format(refresh)} Hz"
    }

    private fun showTouchTest() {
        val test = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF25334A.toInt())
        }
        val label = TextView(this).apply {
            text = "Sentuh dan geser layar di area ini"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        test.addView(label, LinearLayout.LayoutParams(-1, -1))
        setContentView(test)
        test.setOnTouchListener { _, event ->
            label.text = "Touch X: ${event.x.toInt()}\nTouch Y: ${event.y.toInt()}"
            true
        }
        test.setOnLongClickListener { recreate(); true }
        Toast.makeText(this, "Tekan lama untuk kembali", Toast.LENGTH_LONG).show()
    }

    private fun checkInternet() {
        info.text = "Memeriksa koneksi internet..."
        thread {
            val reachable = try {
                java.net.InetAddress.getByName("example.com").isReachable(2500)
            } catch (_: Exception) { false }
            runOnUiThread {
                info.text = if (reachable)
                    "example.com dapat dijangkau. Catatan: ping bisa diblokir jaringan."
                else
                    "Tidak mendapat respons ping. Internet mungkin tetap aktif karena ping dapat diblokir."
            }
        }
    }
}
