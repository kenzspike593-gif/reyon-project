# REY PROJECT
A simple Android utility dashboard built with Kotlin.

Build with JDK 17, Android SDK 35, and Gradle 8.9:
`gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Includes device information, app memory information, display refresh rate,
a touch test, a sound-settings shortcut, and a basic reachability check.
Android restricts true per-game FPS/GPU metrics and system-level performance
controls for ordinary third-party apps.
